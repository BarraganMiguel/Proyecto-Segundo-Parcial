import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useRevistasStore = defineStore('revistas', () => {
  // Función para generar PDF único basado en ID
  const generarPDFUnico = (id, titulo) => {
    // Simulamos diferentes PDFs basados en el ID
    const pdfs = [
      '/PDF REVISTAS/Revista de Ciencias Marinas.pdf',
      '/PDF REVISTAS/Revista de tecnologia.pdf',
      '/PDF REVISTAS/Revista de Ciencias Marinas.pdf', // Reutilizamos pero con diferentes nombres
      '/PDF REVISTAS/Revista de tecnologia.pdf',
    ]

    // Seleccionar PDF basado en el ID
    const pdfIndex = (id - 1) % pdfs.length
    return pdfs[pdfIndex]
  }

  // Función para generar portada única basada en ID
  const generarPortadaUnica = (id) => {
    const portadas = [
      '/descarga.jpg',
      '/RevistaIngTecnologia.jpg',
      '/RevistaEducacion.jpg',
      '/RevistaModa.jpg',
      '/Revsita de Historia.jpg',
    ]

    const portadaIndex = (id - 1) % portadas.length
    return portadas[portadaIndex]
  }

  // Datos iniciales por defecto
  const revistasIniciales = [
    {
      id: 1,
      titulo: 'Revista de Ciencias Marinas',
      autores: 'Juan Pérez, Ana Torres',
      fecha: '2024-03-15',
      area: 'Ciencias Marinas',
      resumen:
        'In pharetra, lacus at suscipit fermentum, felis enim fringilla neque, vel venenatis magna ante nec arcu. Cras odio orci, tempus a tincidunt ac, bibendum sit amet justo.',
      palabrasClave: 'marina, ecosistemas, conservación',
      numeroPaginas: 45,
      portada: '/descarga.jpg',
      archivo: '/PDF REVISTAS/Revista de Ciencias Marinas.pdf',
      estado: 'aprobada',
      autorId: 1,
      autorNombre: 'Juan Pérez',
    },
    {
      id: 2,
      titulo: 'Revista de Ingeniería y Tecnología',
      autores: 'María Ruiz, Luis Bravo',
      fecha: '2024-12-15',
      area: 'Ingeniería',
      resumen:
        'Phasellus dignissim turpis nec euismod sollicitudin. Nulla ac placerat enim, vel porttitor est. Sed lacinia nunc lectus, eget volutpat felis consectetur at.',
      palabrasClave: 'tecnología, ingeniería, innovación',
      numeroPaginas: 38,
      portada: '/RevistaIngTecnologia.jpg',
      archivo: '/PDF REVISTAS/Revista de tecnologia.pdf',
      estado: 'aprobada',
      autorId: 2,
      autorNombre: 'María García',
    },
    {
      id: 3,
      titulo: 'Análisis de ecosistemas costeros en la región de Manabí',
      autores: 'Morales, E.',
      fecha: '2024-05-15',
      area: 'Ciencias Marinas',
      resumen: 'Estudio detallado de los ecosistemas costeros y su impacto ambiental.',
      palabrasClave: 'ecosistemas, costa, Manabí',
      numeroPaginas: 52,
      portada: '/descarga.jpg',
      archivo: '/PDF REVISTAS/Revista de Ciencias Marinas.pdf',
      estado: 'pendiente',
      autorId: 3,
      autorNombre: 'Carlos Ruiz',
    },
  ]

  // Función para cargar revistas desde localStorage
  const cargarRevistasDesdeStorage = () => {
    const revistasGuardadas = localStorage.getItem('revistas')
    if (revistasGuardadas) {
      return JSON.parse(revistasGuardadas)
    }
    return revistasIniciales
  }

  // Función para guardar revistas en localStorage
  const guardarRevistasEnStorage = (revistasData) => {
    localStorage.setItem('revistas', JSON.stringify(revistasData))
  }

  // Inicializar revistas desde localStorage o datos por defecto
  const revistas = ref(cargarRevistasDesdeStorage())

  const getRevistasAprobadas = () => {
    return revistas.value.filter((revista) => revista.estado === 'aprobada')
  }

  const getRevistasPendientes = () => {
    return revistas.value.filter((revista) => revista.estado === 'pendiente')
  }

  const getRevistasByUser = (userId) => {
    console.log('🔍 Buscando revistas para usuario ID:', userId)
    const userRevistas = revistas.value.filter((revista) => {
      console.log(
        `📖 Revista "${revista.titulo}" - autorId: ${revista.autorId}, estado: ${revista.estado}`,
      )
      return revista.autorId === userId
    })
    console.log('📚 Revistas encontradas:', userRevistas.length)
    return userRevistas
  }

  const addRevista = (revistaData) => {
    const newId = Date.now()
    const newRevista = {
      id: newId,
      ...revistaData,
      // ✅ GENERAR PDF Y PORTADA ÚNICOS
      portada: generarPortadaUnica(newId),
      archivo: generarPDFUnico(newId, revistaData.titulo),
      estado: revistaData.estado || 'pendiente',
      fechaCreacion: new Date().toISOString().split('T')[0],
    }

    console.log('✅ Agregando nueva revista:', {
      titulo: newRevista.titulo,
      autorId: newRevista.autorId,
      autorNombre: newRevista.autorNombre,
      estado: newRevista.estado,
      archivo: newRevista.archivo, // ✅ Mostrar qué PDF se asignó
      portada: newRevista.portada, // ✅ Mostrar qué portada se asignó
    })

    revistas.value.push(newRevista)
    guardarRevistasEnStorage(revistas.value)
    return newRevista
  }

  const aprobarRevista = (id) => {
    const revista = revistas.value.find((r) => r.id === id)
    if (revista) {
      revista.estado = 'aprobada'
      console.log('✅ Revista aprobada:', revista.titulo)
      guardarRevistasEnStorage(revistas.value)
    }
  }

  const rechazarRevista = (id) => {
    const index = revistas.value.findIndex((r) => r.id === id)
    if (index !== -1) {
      const revista = revistas.value[index]
      console.log('❌ Revista rechazada:', revista.titulo)
      revistas.value.splice(index, 1)
      guardarRevistasEnStorage(revistas.value)
    }
  }

  const eliminarRevista = (id) => {
    const index = revistas.value.findIndex((r) => r.id === id)
    if (index !== -1) {
      const revista = revistas.value[index]
      console.log('🗑️ Revista eliminada:', revista.titulo)
      revistas.value.splice(index, 1)
      guardarRevistasEnStorage(revistas.value)
    }
  }

  return {
    revistas,
    getRevistasAprobadas,
    getRevistasPendientes,
    getRevistasByUser,
    addRevista,
    aprobarRevista,
    rechazarRevista,
    eliminarRevista,
  }
})
